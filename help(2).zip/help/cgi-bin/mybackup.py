#!/usr/bin/python3
import sys
sys.path.append("H:\\apps\\Python27\\lib\\site-packages")
import cgi
import os

def mymoodle(username):
    os.system("sudo rm -rf /var/www/html/"+username)
    os.system("sudo cp -R /var/backup/%s /var/www/html" %username)




print("Content-type: text/html\n")
print("<title>Result</title>")
print("<body><center>")

form = cgi.FieldStorage()



print('</center></body>')