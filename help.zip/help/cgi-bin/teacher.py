# http://localhost:8247/teacher.html
import sys
sys.path.append("H:\\apps\\Python27\\lib\\site-packages")
import cgi
import os
import csv
import pymysql


TopUser=""
TopPwd=""

def connect_sql():
    os.chdir('/etc/mysql/')
    os.system("sudo chmod o+w debian.cnf")
    os.system("sudo chmod o+r debian.cnf")

    data = ""
    pwdfile = open('/etc/mysql/debian.cnf', "r")
    pwdcontent = pwdfile.read()

    pos = pwdcontent.find("[mysql_upgrade]\nhost     = localhost")
    lenth = len('[mysql_upgrade]\nhost     = localhost')
    UAP = (pwdcontent[pos + lenth:])

    pos_user = UAP.find('user     = ')
    pos_pwd = UAP.find('password = ')
    pos_socket = UAP.find('socket')

    TopUser = UAP[pos_user + len('user     = '):pos_pwd].strip()
    TopPwd = UAP[pos_pwd + len('password = '):pos_socket].strip()

    os.system("sudo chmod o-w debian.cnf")
    os.system("sudo chmod o-r debian.cnf")
    print("top pwd find finish", TopUser, TopPwd)


def confirm_permission(teacher,app,username,pwd):
    if teacher=="a":
        if app == "ftp":
            ftp_change(username, pwd)
        elif app == "phpmyadmin":
            connect_sql()
            phpma_change(username, pwd)
        elif app == "moodle":
            connect_sql()
            moodle_change(username, pwd)
    else:
        print("Your password is wrong ,please check it!")
        print("""
                    <form action="../teacher.html" method="GET">
                        <input type="submit" value="Back to Login">
                    </form>
                    """)

def ftp_change(username,pwd):
    os.system("echo %s:%s| chpasswd" % (username, pwd))

def phpma_change(username,pwd):
    conn = pymysql.connect(host='127.0.0.1', port=3306, user=TopUser, passwd=TopPwd)
    cursor = conn.cursor()

    str1="alter user %s@'%%' identified by %s;"%(username,str(pwd))
    SQLcmd1 = cursor.execute(str1)
    SQLcmd6 = cursor.execute("flush privileges;")
    conn.commit()
    cursor.close()
    conn.close()


def moodle_change(pwd):
    sql = "UPDATE mdl_user SET password = %s WHERE username = 'admin'"
    conn = pymysql.connect(host='127.0.0.1', port=3306, user=TopUser, passwd=TopPwd)
    cursor = conn.cursor()

    cursor.excecute(sql, pwd)

    conn.commit()

    print(cursor.rowcount, "record(s) affected")



print("Content-type: text/html\n")
print("</title>")
print("<body><center>")

form = cgi.FieldStorage()
teacher = form['teacher'].value if 'teacher' in form else ''
app = form['app'].value if 'app' in form else ''
username = form['account'].value if 'account' in form else ''
pwd = form['pwd'].value if 'pwd' in form else ''
confirm_permission(teacher,app,username,pwd)

print(app)
print('</center></body>')